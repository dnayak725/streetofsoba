import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dinning-location',
  templateUrl: './dinning-location.page.html',
  styleUrls: ['./dinning-location.page.scss'],
})
export class DinningLocationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
