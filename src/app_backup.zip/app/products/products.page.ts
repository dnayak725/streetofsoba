import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';
import { ModalController } from '@ionic/angular';
import { BaseModalPage } from '../base-modal/base-modal.page';

@Component({
  selector: 'app-products',
  templateUrl: './products.page.html',
  styleUrls: ['./products.page.scss'],
})
export class ProductsPage implements OnInit {
  segmentModel = 0;
  constructor(private service:SharedService, private route:Router, private localstore:LocalStorageService,public modalController: ModalController,) {}
  itemlist:any; 
  arrayitem:any = [];
  tabitem: any =[];
  mytabid = 0;
  dataReturned: any;


  ngOnInit() {
    this.items();
  
  }
  async openModal() {
    const modal = await this.modalController.create({
      component: BaseModalPage,
      componentProps: {
      
      },
    });

    modal.onDidDismiss().then((dataReturned) => {
      if (dataReturned !== null) {
        this.dataReturned = dataReturned.data;
        //alert('Modal Sent Data :'+ dataReturned);
      }
    });

    return await modal.present();
  }

  segmentChanged(event){
  console.log(event)
  }
  items(){
    this.service.getApi().subscribe(res=>{
      this.itemlist = res;
      this.arrayitem = this.itemlist.data
      this.tabitem = this.itemlist.data[0].items
      console.log(this.tabitem)
   

      // for (let i = 0; i < this.itemlist.data.length; i++) {
      //  this.tabitem = this.itemlist.data[i].items
      //  console.log(this.tabitem); 
        
      // }
    })
  }

  tabId(i:any){
  this.mytabid = i
   this.tabitem = this.itemlist.data[i].items
  }

  productDetails(id:any,image:any,desc:any,name:any,options:any,basicprice:any=0.0){

 if(options.length == 0){
 
  this.openModal()

 }else{
    this.localstore.clear("checkboxdata")
   this.service.destroyCartarray();
    this.route.navigate(['/product-details', { id: id, image: image, itemdesc: desc, catname: name,basicprice:basicprice}])
   }
   
  }

}
