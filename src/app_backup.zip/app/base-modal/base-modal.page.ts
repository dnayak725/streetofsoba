import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';
import { ModalController, NavParams } from '@ionic/angular';
import { SharedService } from '../shared.service';
import { IonContent, } from '@ionic/angular';  
@Component({
  selector: 'app-base-modal',
  templateUrl: './base-modal.page.html',
  styleUrls: ['./base-modal.page.scss'],
})

export class BaseModalPage implements OnInit {

  @ViewChild(IonContent, {static: false}) content: IonContent;  

  inboundClick = true;
    outboundClick = true;
    private scrollDepthTriggered = false;
  constructor(
    private modalController: ModalController,
    private localstore: LocalStorageService,
    private service: SharedService
  ) {}
  
  @Input() filtermodal: any=[];
  @Input() variable: any;
  @Input() optionimg: any;
  @Input() itemName: any;
  @Input() baseprice: any=0.0;
  @Input() buttontype:any;
  cartSize: any = [];
  checkboxLength: any = [];
  cartaddPrice: any = [];
  cartPriceSum: any = 0.0;
  showHide: boolean = true;
  hideShow: boolean = false;
  
  ngOnInit() {}
  async closeModel() {
    const close: string = 'Modal Removed';
    await this.modalController.dismiss(close);
  }

  // ScrollToBottom() {  
  //   this.content.scrollToBottom(1500);  
  // }  
  ScrollToTop() {  
    this.content.scrollToTop(500);  
  }

  async logScrolling($event) {
    if(this.scrollDepthTriggered) {
      return;
    }
    if($event.target.localName != "ion-content") {
      return;
    }

    const scrollElement = await $event.target.getScrollElement();
    const scrollHeight = scrollElement.scrollHeight - scrollElement.clientHeight;
    console.log({scrollHeight});

    const currentScrollDepth = $event.detail.scrollTop;
    console.log({currentScrollDepth});

    const targetPercent = 90;

    let triggerDepth = ((scrollHeight / 100) * targetPercent);
    console.log({triggerDepth});

    if(currentScrollDepth > triggerDepth) {
      console.log("100%");
      this.showHide = false;
      this.hideShow = true;
    }

    if(currentScrollDepth == 0) {
      console.log("0%");
      this.showHide = true;
      this.hideShow = false;
    }
  } 

  checkvalue(
    checkvalue: any,
    variableName: any,
    addtitionalPrice: any,
    itemname:any,
    baseprice:any= 0.0,) {
      
    this.checkboxLength = [];
    this.service.checkboxGet(
      {
      "checkboxvalue": checkvalue,
      "variableName": variableName,
      "addprice": addtitionalPrice,
      "itemName": itemname,
      "baseprice":baseprice,
      "buttontype":this.buttontype,
    }
    );

    console.log(this.checkboxLength)
  }


  actionMethod() {
    this.content.scrollToBottom(500);
    this.showHide = false;
    //($event.target as HTMLButtonElement).hidden = true; 
 }
 
}

