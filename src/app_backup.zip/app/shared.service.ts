import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LocalStorageService } from 'ngx-webstorage';
@Injectable({
  providedIn: 'root',
})
export class SharedService {
  // optionGlobalName:any;
  cartSize: any = [];
  checkBoxValue: any = [];
  finalCheck: any = [];
  finaloptionData: any = [];
  constructor(
    private http: HttpClient,
    private localstore: LocalStorageService
  ) {}
  getApi() {
    let url = 'https://poke-theory.quocent.com/api/products';
    return this.http.get(url);
  }
  getoptions(id: any) {
    let url = 'https://poke-theory.quocent.com/api/product/' + id;
    return this.http.get(url);
  }

  destroyCartarray() {
    this.checkBoxValue = [];
  }

  // getcartArray(x:any){
  //   let s = false
  //   for(let i=0; i< this.cartSize.length;i++){
  //     if(this.cartSize[i]['varname'] == x['varname']){
  //       this.cartSize[i] = x;

  //       s =true;
  //     }
  //   }
  //   if(s == false){
  //     this.cartSize.push(x)
  //   }
  //   this.localstore.store("cart",this.cartSize)

  //   }

  checkboxGet(checkdata) {
    if (checkdata['buttontype'] == 'radio') {
      console.log('hii');
      let a = false;
      let b = false;
      let index: any;
      for (let i = 0; i < this.finaloptionData.length; i++) {
        if (this.finaloptionData[i]['itemName'] == checkdata['itemName']) {
          a = true;
          if (this.finaloptionData[i]['variableName'] == checkdata['variableName']) {
            b = true;
            index = i;
          }
        }
      }
      if (a == false ||(a == true && b == false)) {
        this.finaloptionData.push(checkdata);

      } else {
        // index value replace
        this.finaloptionData[index]['checkboxvalue'] = checkdata['checkboxvalue'];
      }
    } else {
      console.log('hlo');
      let a = false;
      let b = false;
      let c = false;
      let index: any;
      for (let i = 0; i < this.finaloptionData.length; i++) {
        if (this.finaloptionData[i]['itemName'] == checkdata['itemName']) {
          c = true;
          if (this.finaloptionData[i]['variableName'] == checkdata['variableName'] ) {
            a = true;
            if (this.finaloptionData[i]['checkboxvalue'] ==  checkdata['checkboxvalue']) {
              // Delete the index
              const index1 = this.finaloptionData.indexOf(this.finaloptionData[i]);
              if (index1 > -1) {
                this.finaloptionData.splice(index1, 1);
              }
              b = true;
            }
          }
      }
      }
      // if (a == false || (a == true && b == false)) {
        if (c == false || (c == true && a == false)|| (a == true && b == false)) {

        this.finaloptionData.push(checkdata);
      }
    }

    console.log(this.finaloptionData);
        this.localstore.store("checkboxdata",this.finaloptionData)

    // this.checkBoxValue.push(checkdata)
    // this.localstore.store("checkboxdata",checkdata)

    // this.finalCheck = this.checkBoxValue.reduce((accumalator, current) => {
    //   if (
    //     !accumalator.some(
    //       (item) => item.checkvalue == current.checkvalue
    //     )
    //   ) {
    //     accumalator.push(current);
    //   }
    //   return accumalator;
    // }, []);
    // this.localstore.store("checkboxdata",this.finalCheck)
    // console.log(this.finalCheck)
  }
}
