import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.page.html',
  styleUrls: ['./order-list.page.scss'],
})
export class OrderListPage implements OnInit {
  cartData: any = [];
  filteroption: any = [];
  finalCartValue: any = [];
  baseOptionPrice: any = 0.0;
  totalCartPrice:any=0.0;
  tofixTotalcartPrice:any=0.0;

  constructor(private localstore: LocalStorageService) {}

  ngOnInit() {
  
    this.cartData = this.localstore.retrieve('checkboxdata');

    let a = false
    let b = false
    let index1:any
    let index2:any
    console.log(this.cartData)
    for(let i=0; i< this.cartData.length;i++){
      for(let j=0; j<this.finalCartValue.length; j++){
        if(this.cartData[i]['itemName'] == this.finalCartValue[j]['itemName']){
          a =true;
          index2 = j
        } 
      }
      if(a == false){
        this.finalCartValue.push({"itemName":this.cartData[i]['itemName'],"total":this.cartData[i]['addprice']+this.cartData[i]['baseprice']});      
      }else{
        this.finalCartValue[index2]["total"] = this.finalCartValue[index2]["total"] + this.cartData[i]["addprice"];      

        a = false
      }
    }
    console.log(this.finalCartValue)
    for(let i=0; i<this.finalCartValue.length; i++){
this.totalCartPrice += this.finalCartValue[i].total
this.tofixTotalcartPrice = this.totalCartPrice
    }
  }


  removecart(item:any){
    for(let i=0; i<this.finalCartValue.length; i++){
     if(this.finalCartValue[i].itemName == item){
        const index1 = this.finalCartValue.indexOf(this.finalCartValue[i]);
        if (index1 > -1) {
          this.finalCartValue.splice(index1, 1);
        
      }
    }
    console.log(this.finalCartValue)
  
    }
  }
}

