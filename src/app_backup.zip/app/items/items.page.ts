import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';
@Component({
  selector: 'app-items',
  templateUrl: './items.page.html',
  styleUrls: ['./items.page.scss'],
})
export class ItemsPage implements OnInit {

  constructor(private service:SharedService, private route:Router, private localstore:LocalStorageService) { }
itemlist:any; 
arrayitem:any = [];

  ngOnInit() {
    this.items();
  }
  items(){
    this.service.getApi().subscribe(res=>{
      this.itemlist = res;
      this.arrayitem = this.itemlist.data
    
     
    })
  }
  productList(id:any){
    this.localstore.store('itemid', id);
    this.route.navigate(['/products'])
  }
}
