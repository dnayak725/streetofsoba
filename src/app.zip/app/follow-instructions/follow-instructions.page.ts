import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-follow-instructions',
  templateUrl: './follow-instructions.page.html',
  styleUrls: ['./follow-instructions.page.scss'],
})
export class FollowInstructionsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
