import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-snacks',
  templateUrl: './add-snacks.page.html',
  styleUrls: ['./add-snacks.page.scss'],
})
export class AddSnacksPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
