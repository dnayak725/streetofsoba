import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { BaseModalPage } from '../base-modal/base-modal.page';
import { SharedService } from '../shared.service';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.page.html',
  styleUrls: ['./product-details.page.scss'],
})
export class ProductDetailsPage implements OnInit {
  constructor(
    public modalController: ModalController,
    private service: SharedService,
    private route: Router,
    private localstore: LocalStorageService,
    private activeroute: ActivatedRoute
  ) {}
  dataReturned: any;
  itemlist: any;
  arrayitem: any = [];
  tabitem: any = [];
  itemid: any;
  itemimage: any;
  itemdesc: any;
  itemname: any;
  optionsdata: any = [];
  optionlist: any;
  alloption: any = [];
  filteroption: any = [];
  optionname: any;
  variableArray: any = [];
  optionName: any;
  reduceOptions: any = [];

  ngOnInit() {
    this.prodDetails();
    this.activeroute.params.subscribe((params) => {
      this.itemid = params['id'];
      this.itemimage = params['image'];
      this.itemdesc = params['itemdesc'];
      this.itemname = params['catname'];

      this.getoption(this.itemid);
    });


  }

  async openModal() {
    const modal = await this.modalController.create({
      component: BaseModalPage,
      componentProps: {
        filtermodal: this.variableArray,
        variable: this.optionname,
        optionimg: this.itemimage,
        itemName: this.itemname,
      },
    });

    modal.onDidDismiss().then((dataReturned) => {
      if (dataReturned !== null) {
        this.dataReturned = dataReturned.data;
        //alert('Modal Sent Data :'+ dataReturned);
      }
    });

    return await modal.present();
  }

  prodDetails() {
    this.service.getApi().subscribe((res) => {
      this.itemlist = res;
      this.arrayitem = this.itemlist.data;
    });
  }
  getoption(itemId: any) {
    this.service.getoptions(itemId).subscribe((res) => {
      this.optionlist = res;
      this.alloption = this.optionlist.data;
  
      this.filteroption = this.alloption.reduce((accumalator, current) => {
        if (
          !accumalator.some(
            (item) => item.variable_name === current.variable_name
          )
        ) {
          accumalator.push(current);
        }
        return accumalator;
      }, []);
      // console.log(this.filteroption)
    });
  }

  optionVar(variable: any) {
   
 
    this.optionname = variable;
    this.optionName = this.localstore.retrieve('optionname');
    // console.log(this.optionName)
    //    for (let i=0; i< this.optionsdata.length; i++) {
    // console.log("hii");
    //    }
    this.variableArray = [];
    this.alloption.forEach((element) => {
      if (element.variable_name == this.optionname) {
        this.variableArray.push(element);
      }
    });
    // console.log(this.variableArray)
    this.openModal();
    
  }

  // get globalOptName(): any {
  //   return this.localstore.retrieve('cart');
  // }

  get globalCheckbox(): any {
    return this.localstore.retrieve('checkboxdata');
  }

addCart(){
  this.route.navigate(["/order-list"])
}
}
