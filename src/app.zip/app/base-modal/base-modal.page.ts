import { Component, OnInit, Input } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';
import { ModalController, NavParams } from '@ionic/angular';
import { SharedService } from '../shared.service';
@Component({
  selector: 'app-base-modal',
  templateUrl: './base-modal.page.html',
  styleUrls: ['./base-modal.page.scss'],
})
export class BaseModalPage implements OnInit {
  constructor(
    private modalController: ModalController,
    private localstore: LocalStorageService,
    private service: SharedService
  ) {}
  @Input() filtermodal: [];
  @Input() variable: any;
  @Input() optionimg: any;
  @Input() itemName: any;
  cartSize: any = [];
  checkboxLength: any = [];
  cartaddPrice: any = [];
  cartPriceSum: any = 0.0;


  ngOnInit() {}
  async closeModel() {
    const close: string = 'Modal Removed';
    await this.modalController.dismiss(close);
  }

  // optionName(optname:any,var_name:any){
  //   this.service.getcartArray( {"optionname":optname,"varname":var_name})

  // }

  checkvalue(
    checkvalue: any,
    variableName: any,
    addtitionalPrice: any,
    itemname:any) {
 
// this.cartaddPrice.push(addtitionalPrice);

// for (let i = 0; i < this.cartaddPrice.length; i++) {
//  this.cartPriceSum += this.cartaddPrice[i];
// }

    
    // this.checkboxLength = [];
    this.service.checkboxGet({
      checkboxvalue: checkvalue,
      variableName: variableName,
      addprice: addtitionalPrice,
      itemName: itemname,
    });

    this.checkboxLength.push(checkvalue);

    if (
      (this.checkboxLength.length == 2 && variableName == 'Size') ||
      (this.checkboxLength.length == 4 && variableName == 'Base\r\n') ||
      (this.checkboxLength.length == 2 && variableName == 'Toppings')
    ) {
      this.closeModel();
    }
  }
}
