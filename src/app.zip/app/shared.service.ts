import { Injectable } from '@angular/core';
import { HttpClient} from  '@angular/common/http';
import { LocalStorageService } from 'ngx-webstorage';
@Injectable({
  providedIn: 'root'
})
export class SharedService {
  // optionGlobalName:any;
  cartSize:any =[];
  checkBoxValue:any =[];
  finalCheck:any =[];
  constructor(private http:HttpClient,private localstore:LocalStorageService) { }
  getApi(){
    let url = "https://poke-theory.quocent.com/api/products";
    return this.http.get(url)
  }
  getoptions(id:any){
    let url = "https://poke-theory.quocent.com/api/product/"+id;
    return this.http.get(url)
  }

  destroyCartarray(){
    this.checkBoxValue = []
  }

  // getcartArray(x:any){
  //   let s = false
  //   for(let i=0; i< this.cartSize.length;i++){
  //     if(this.cartSize[i]['varname'] == x['varname']){
  //       this.cartSize[i] = x;
    
  //       s =true;
  //     }
  //   }
  //   if(s == false){
  //     this.cartSize.push(x)
  //   }
  //   this.localstore.store("cart",this.cartSize)

  //   }

    checkboxGet(checkdata:any){
    
      this.checkBoxValue.push(checkdata)
      this.localstore.store("checkboxdata",this.checkBoxValue)
    
      // this.finalCheck = this.checkBoxValue.reduce((accumalator, current) => {
      //   if (
      //     !accumalator.some(
      //       (item) => item.checkvalue == current.checkvalue
      //     )
      //   ) {
      //     accumalator.push(current);
      //   }
      //   return accumalator;
      // }, []);
      // this.localstore.store("checkboxdata",this.finalCheck)
      // console.log(this.finalCheck)
 
      
    }
  
}
