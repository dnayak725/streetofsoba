import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.page.html',
  styleUrls: ['./order-list.page.scss'],
})
export class OrderListPage implements OnInit {
cartData:any = [];
filteroption:any = [];
finalCartValue:any = []
cartdDataPrice:any =0.0;
totalCartValue:any =0.0;

  constructor(private localstore: LocalStorageService,) { }

  ngOnInit() {
    this.cartData  = this.localstore.retrieve("checkboxdata")


    for(let i=0; i< this.cartData.length; i++){
  
      this.cartdDataPrice += this.cartData[i].addprice
     this.totalCartValue = this.cartdDataPrice.toFixed(2)
  

    }
    // let s = false
    // for(let i=0; i< this.cartData.length;i++){
    //   for(let j=0; j<this.finalCartValue.length; j++)
    //   if(this.cartData[i]['varname'] == this.finalCartValue['varname']){
    //     this.cartData[i] =this.cartData;
    
    //     s =true;
    //   }
    // }
    // if(s == false){
    //   this.cartData.push(this.cartData)
    // }

  }

}
